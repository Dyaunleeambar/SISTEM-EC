-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: colaboradores_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditoria_cambios`
--

DROP TABLE IF EXISTS `auditoria_cambios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditoria_cambios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `tabla_afectada` varchar(50) NOT NULL,
  `accion` varchar(20) NOT NULL,
  `registro_id` int DEFAULT NULL,
  `datos_anteriores` json DEFAULT NULL,
  `datos_nuevos` json DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `fecha_cambio` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `auditoria_cambios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria_cambios`
--

LOCK TABLES `auditoria_cambios` WRITE;
/*!40000 ALTER TABLE `auditoria_cambios` DISABLE KEYS */;
/*!40000 ALTER TABLE `auditoria_cambios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cambios_password`
--

DROP TABLE IF EXISTS `cambios_password`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cambios_password` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `fecha_cambio` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `cambios_password_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cambios_password`
--

LOCK TABLES `cambios_password` WRITE;
/*!40000 ALTER TABLE `cambios_password` DISABLE KEYS */;
INSERT INTO `cambios_password` VALUES (1,1,'2025-07-31 10:22:02','::1');
/*!40000 ALTER TABLE `cambios_password` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colaboradores`
--

DROP TABLE IF EXISTS `colaboradores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colaboradores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `fecha_salida` varchar(20) DEFAULT NULL,
  `fecha_entrada` varchar(20) DEFAULT NULL,
  `fin_mision` tinyint DEFAULT NULL,
  `ubicacion` varchar(255) DEFAULT NULL,
  `orden` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_nombre_estado` (`nombre`,`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colaboradores`
--

LOCK TABLES `colaboradores` WRITE;
/*!40000 ALTER TABLE `colaboradores` DISABLE KEYS */;
INSERT INTO `colaboradores` VALUES (2,'Heidy Mojena Pagán','Caracas','','',0,'Caracas',3),(4,'Eduardo Eugenio Mariño Ricardo','Caracas','','',0,'Caracas',4),(5,'Barbara Berenguer Rámirez','Caracas','','',0,'Caracas',5),(6,'Yuliet Hernández Acosta','Caracas','','',0,'Caracas',6),(7,'Nolberto Almeida Escalona','Caracas','','',0,'Caracas',7),(8,'Miguel González Díaz','Caracas','','',0,'Caracas',8),(9,'Daniel Fajardo Casanova','Caracas','','',0,'Caracas',9),(10,'Wilber Nazur Peña','Caracas','','',0,'Caracas',10),(11,'Willian Norberto Chongo Veitía','Caracas','','',0,'Caracas',11),(12,'Daynier Varona Pacheco','Caracas','','',0,'Caracas',13),(13,'Yabel Cansino Veloso','Caracas','2025-07-19','',0,'Caracas',14),(14,'Eilier Pérez Espinosa','Caracas','','',0,'Caracas',15),(15,'Rolando Ernesto Baryola Chirino','Caracas','','',0,'Caracas',16),(16,'Wilmer Robles Alvarez','Caracas','','',0,'Caracas',17),(17,'Yaimel Cantero López','Caracas','','',0,'Caracas',18),(18,'Julio Cesar Portelles Escobar','Caracas','','',0,'Caracas',19),(19,'Pedro Antonio Delgado López','Caracas','','',0,'Caracas',20),(20,'Zobeida María Bárzaga Pérez','Anzoátegui','','',0,'Anzoátegui',21),(21,'Mario Huerta González','Anzoátegui','2025-07-23','',0,'Anzoátegui',22),(22,'Ernesto Labañino Rigñack','Anzoátegui','2025-07-23','',1,'Anzoátegui',23),(23,'Yerandi Alemán Orfila','Anzoátegui','','',0,'Anzoátegui',24),(24,'Israel de Jesus Rosales Crespo','Anzoátegui','','',0,'Anzoátegui',25),(25,'Edy Verdecia Almaguer','Anzoátegui','','',0,'Anzoátegui',26),(26,'Gerardo Luis Avila Galano','Anzoátegui','','',0,'Anzoátegui',27),(27,'Alejandro López Vázquez','Anzoátegui','','',0,'Anzoátegui',28),(28,'Osmel Castillo Neyra','Anzoátegui','','',0,'Anzoátegui',29),(29,'Nicolas Gonzalez Cajete','Barinas','','',0,'Barinas',31),(30,'Delbis Castro Scull','Barinas','','',0,'Barinas',32),(31,'Henrry Castellanos Vibert','Barinas','','',0,'Barinas',33),(32,'Yosmany Morejón Cordoves','Barinas','','',0,'Barinas',34),(33,'Arnel González  Vergara','Barinas','','',0,'Barinas',35),(34,'Renier Garcia Tamayo','Barinas','2025-07-05','',0,'Barinas',36),(35,'Yoanquy Curbelo Delgado','Barinas','2025-07-26','',0,'Barinas',37),(37,'Alexey Martinez Rodriguez','Bolívar','','',0,'Bolívar',38),(38,'Omar de la Cruz Hernández','Bolívar','2025-07-23','',0,'Bolívar',39),(39,'Yoixander Manuel Peralta Simón','Bolívar','','',0,'Bolívar',40),(40,'Liuver García MartÍnez','Bolívar','','',0,'Bolívar',41),(41,'Antonio Martínez Aguilar','Bolívar','','',0,'Bolívar',42),(43,'Elio Javier Gómez Aguilar','Bolívar','','',0,'Bolívar',43),(44,'Andres Garcia Perasmo','Bolívar','2025-06-10','2025-07-22',0,'Bolívar',44),(45,'Argemis Ramos Paradela','Bolívar','','',0,'Bolívar',45),(46,'Carlos Enrique Alvarez Caboverde','Bolívar','','',0,'Bolívar',46),(47,'Yoiler Sanfiel Guerra','Bolívar','2025-06-11','2025-07-22',0,'Bolívar',47),(48,'José Ramón Morffi Mena','Bolívar','','',0,'Bolívar',48),(49,'Jorge Luis Pupo de la Cruz','Carabobo','','',0,'Carabobo',49),(50,'Erdwin Díaz Ramos','Carabobo','2025-07-26','',0,'Carabobo',50),(51,'Yane Licea Aguilar','Carabobo','','',0,'Carabobo',51),(52,'Orlando Díaz Durañona','Carabobo','','',0,'Carabobo',52),(53,'Sergio Borges Terry','Carabobo','','',0,'Carabobo',53),(54,'Alexander Noguera Salgado','Carabobo','','',0,'Carabobo',54),(55,'Lazaro Renato Banguela Aguilar','Carabobo','','',0,'Carabobo',55),(56,'Laercio Espinosa Álvarez','Carabobo','','',0,'Carabobo',56),(57,'Yunior Peña Ferrero','Carabobo','','',0,'Carabobo',57),(58,'Alfredo Miguel Martínez Morell','Carabobo','','',0,'Carabobo',58),(59,'Roberlandis Estevez Castillo','Carabobo','','',0,'Carabobo',59),(60,'Alexis Espinosa Espinosa','Carabobo','','',0,'Carabobo',60),(61,'Arnoldis Hechavarria Ortiz','Carabobo','','',0,'Carabobo',61),(62,'Pablo Yasmani Nordet Anaya','Carabobo','','',0,'Carabobo',62),(63,'Raúl Remon Figueredo','Zulia','','',0,'Zulia',64),(64,'Janys Alfredo Aguilera Vega','Zulia','','',0,'Zulia',65),(66,'Alberto Iznaga Téllez','Zulia','2025-07-16','',0,'Zulia',66),(67,'Victor Leyva Diaz','Zulia','','',0,'Zulia',67),(68,'José Alberto Massanet Fernández','Zulia','2025-07-05','',0,'Zulia',68),(69,'Juan Francisco Fabré Mustelier','Zulia','','',0,'Zulia',69),(70,'Yunier Valiente Valier','Zulia','2025-06-10','2025-07-22',0,'Zulia',70),(71,'Tomás Armando Zerquera Torres','Zulia','','',0,'Zulia',71),(72,'Juan Luis Valdés Gutíerrez','Zulia','','',0,'Zulia',72),(73,'Ariel Espinel Moya','Zulia','','',0,'Zulia',73),(74,'Yordanis Galban Falcon','Zulia','','',0,'Zulia',75),(76,'Julio Cesar Reyes','Caracas','','',0,'Caracas',1),(77,'Denis Martínez Recio','Caracas','','',0,'Caracas',2),(78,'Carlos Luis Martínez García','Caracas','','',0,'Caracas',12),(80,'Carlos Medina Torres','Carabobo','','',0,'Carabobo',63),(81,'Miguel Tarifa Padron','Anzoátegui','','',0,'Anzoátegui',30),(86,'Eliazar Alpajon Guilarte','Zulia','','',0,'Zulia',74);
/*!40000 ALTER TABLE `colaboradores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sesiones`
--

DROP TABLE IF EXISTS `sesiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sesiones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `token_id` varchar(255) DEFAULT NULL,
  `fecha_login` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_logout` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `sesiones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesiones`
--

LOCK TABLES `sesiones` WRITE;
/*!40000 ALTER TABLE `sesiones` DISABLE KEYS */;
INSERT INTO `sesiones` VALUES (1,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidGltZXN0YW1wIjoxNzUzOTU2NTkyMDUyLCJpYXQiOjE3NTM5NTY1OTIsImV4cCI6MTc1Mzk2MDE5Mn0.MhECoG82GqYW7O-Cs5d2IDLADf2_ezg-hmsGJ953JXE','2025-07-31 10:09:52',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) sistema-estimulacion/1.0.0 Chrome/120.0.6099.291 Electron/28.3.3 Safari/537.36'),(2,12,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTIsInRpbWVzdGFtcCI6MTc1Mzk1NjgyMTg5NSwiaWF0IjoxNzUzOTU2ODIxLCJleHAiOjE3NTM5NjA0MjF9.XVIOBuwjxYtxYAGh4AuKodDfId-KWOSHWGocUh9Wq_k','2025-07-31 10:13:41',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) sistema-estimulacion/1.0.0 Chrome/120.0.6099.291 Electron/28.3.3 Safari/537.36'),(3,12,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTIsInRpbWVzdGFtcCI6MTc1Mzk1NzIwMzU5MCwiaWF0IjoxNzUzOTU3MjAzLCJleHAiOjE3NTM5NjA4MDN9.3l9jsIQmELHAMOOORB3AjfCaRzTLCld0HCH7Y87659A','2025-07-31 10:20:03',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) sistema-estimulacion/1.0.0 Chrome/120.0.6099.291 Electron/28.3.3 Safari/537.36'),(4,12,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MTIsInRpbWVzdGFtcCI6MTc1Mzk1NzIzNDYyNCwiaWF0IjoxNzUzOTU3MjM0LCJleHAiOjE3NTM5NjA4MzR9.AwctElfnNpHxwX_I0uwaHbRN2sPJXB_hPmCfMzVng50','2025-07-31 10:20:34',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) sistema-estimulacion/1.0.0 Chrome/120.0.6099.291 Electron/28.3.3 Safari/537.36'),(5,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidGltZXN0YW1wIjoxNzUzOTU3MjgxMjE4LCJpYXQiOjE3NTM5NTcyODEsImV4cCI6MTc1Mzk2MDg4MX0.e5EHelV1vnucg3E5WHonoZa6WnjBeolFzcZkFqD_u6U','2025-07-31 10:21:21',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) sistema-estimulacion/1.0.0 Chrome/120.0.6099.291 Electron/28.3.3 Safari/537.36'),(6,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidGltZXN0YW1wIjoxNzUzOTU3MzUxNDg2LCJpYXQiOjE3NTM5NTczNTEsImV4cCI6MTc1Mzk2MDk1MX0.3bvXzBcEETlQ28wc3ycGCJVZ7o0ySOwXqJevr6uzOmY','2025-07-31 10:22:31',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) sistema-estimulacion/1.0.0 Chrome/120.0.6099.291 Electron/28.3.3 Safari/537.36'),(7,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidGltZXN0YW1wIjoxNzUzOTU4MDA3NjkwLCJpYXQiOjE3NTM5NTgwMDcsImV4cCI6MTc1Mzk2MTYwN30.vgVgop64SLzVDUpJw_URYihoRU4o5jJgcUi--zEs7Dg','2025-07-31 10:33:27',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) sistema-estimulacion/1.0.0 Chrome/120.0.6099.291 Electron/28.3.3 Safari/537.36'),(8,1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidGltZXN0YW1wIjoxNzUzOTU4MDMwMTAzLCJpYXQiOjE3NTM5NTgwMzAsImV4cCI6MTc1Mzk2MTYzMH0.HYPaDnQ5b1aVdNlECAsPeDUFe7ARjK64uFxytbe3Ydc','2025-07-31 10:33:50',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) sistema-estimulacion/1.0.0 Chrome/120.0.6099.291 Electron/28.3.3 Safari/537.36');
/*!40000 ALTER TABLE `sesiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `rol` enum('admin','editor','viewer') DEFAULT 'viewer',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ultimo_login` timestamp NULL DEFAULT NULL,
  `ultimo_cambio_password` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`),
  KEY `idx_rol` (`rol`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'admin','$2a$12$NPd1sFhIFg8hE/4XkQjFOuL1cqTVZSbY/IevaqtlI/SQ1PTQbVn4S','admin@sistema.com','admin','2025-07-28 05:07:04','2025-07-31 10:33:50','2025-07-31 10:22:02',1),(12,'Eugenio','$2a$12$YM7JTWwtz8MaHWed7x3ZceeB5l1TWGWcEwyhDzgks/tx4EFdCHvHy','eugenio@gmail.com','editor','2025-07-28 05:51:10','2025-07-31 10:20:34','2025-07-28 05:51:10',1);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'colaboradores_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-31  6:39:27
